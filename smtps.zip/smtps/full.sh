
#!/bin/sh




if [ "$#" -ne 1 ]; then
    echo "ip2hosts <ip>"
	exit 1
fi

ip2hosts() { 

	ip_real=$1
	rm /tmp/domains.txt  2>/dev/null
	#curl -ks https://freeapi.robtex.com/ipquery/$1 | grep -Po "(?<=\"o\":).*?(?=,)" | sed 's/\"//g' >> /tmp/domains.txt
	#curl "http://www.virustotal.com/vtapi/v2/ip-address/report?ip=$1&apikey=3c052e9a7339f3a73f00bd67baea747e47f59ee6c1596e59590fd953d00ce519" -s | json_pp 2>/dev/null | grep -Po "(?<=\"hostname\" : \").*?(?=\",)" >> /tmp/domains.txt
	#curl -s https://www.robtex.com/private/html?rev=$1 | grep -Po "(?<=<td>).*?(?=</td>)" | head -1 >> /tmp/domains.txt
	#curl -i -s -k  -X 'POST' -F "theinput=$1" -F "thetest=reverseiplookup" -F "name_of_nonce_field=23gk"    'https://hackertarget.com/reverse-ip-lookup/' | grep -Poz "(?s)(?<=<pre id=\"formResponse\">).*?(?=</pre>)" >> /tmp/domains.txt
	dig +short -x $1 >> /tmp/domains.txt
	#for i in {0..9}; do curl "https://www.bing.com/search?q=ip%3a$1&first=$i1" -s |  grep -Po "(?<=<a href=\").*?(?= h=)" | grep -Po "(?<=://).*?(?=/)" | egrep -v "microsoft|bing|pointdecontact"; done >> /tmp/domains.txt
	seq 0 9 | xargs -n1 -P4 bash -c 'i=$0; url="https://www.bing.com/search?q=ip%3a'$1'&first=${i}1"; curl -s $url | grep -Po "(?<=<a href=\").*?(?= h=)" | grep -Po "(?<=://).*?(?=/)" | egrep -v "microsoft|bing|pointdecontact"' >> /tmp/domains.txt
	#nmap -Pn -p443 --script ssl-cert $1 | grep Subject | grep -Po "(?<=commonName=).*?(?=/)" | tr '[:upper:]' '[:lower:]' >> /tmp/domains.txt
	sed -i 's/\.$//g' /tmp/domains.txt
	curl -X POST -F "remoteAddress=$1"  http://domains.yougetsignal.com/domains.php -s | /usr/bin/perl -p | grep -Poz "(?s)\[.*\]" | cat -v | grep -Po "(?<=\").+(?=\")" >> /tmp/domains.txt
	curl -i -s -k  -X 'POST' -F "theinput=$1" -F "thetest=reverseiplookup" -F "name_of_nonce_field=23gk"    'https://hackertarget.com/reverse-ip-lookup/' | grep -Poz "(?s)(?<=<pre id=\"formResponse\">).*?(?=</pre>)" | grep -Piva "no records" | grep -Pa \w>> /tmp/domains.txt
	curl -i -s -k  -X 'GET' 'https://www.threatcrowd.org/graphHtml.php?ip=$1' | grep -Po "(?<=source: ').*?(?=')" | egrep -v ^[0-9] | sort -u >> /tmp/domains.txt
	sort -u /tmp/domains.txt



 }
 

	ip2hosts $1 >text.txt



output(){	
        filename=text.txt
while read -r line
do
        p="$line"
        length=$(echo $p | grep -o "\." | grep -c "\.")
        link=$p
        fst=$length
        scnd=`expr $length + 1`
        thrd=`expr $length - 1`
        end=$(echo $link | cut -d"." -f$fst,$scnd)

	
	
	
DOMAIN_LIST="com.ac edu.ac gov.ac mil.ac net.ac org.ac ac.ae co.ae com.ae gov.ae net.ae 
 org.ae pro.ae sch.ae com.ai edu.ai gov.ai org.ai com.ar edu.ar gov.ar int.ar
 mil.ar net.ar org.ar ac.at co.at gv.at or.at priv.at act.au asn.au com.au
 conf.au csiro.au edu.au gov.au id.au id.au info.au net.au nsw.au org.au otc.au
 oz.au qld.au sa.au tas.au telememo.au vic.au wa.au com.az net.az org.az com.bb
 net.bb org.bb ac.be belgie.be dns.be fgov.be com.bh edu.bh gov.bh net.bh org.bh
 com.bm edu.bm gov.bm net.bm org.bm adm.br adv.br agr.br am.br arq.br art.br
 ato.br bio.br bmd.br cim.br cng.br cnt.br com.br coop.br ecn.br edu.br eng.br
 esp.br etc.br eti.br far.br fm.br fnd.br fot.br fst.br ggf.br gov.br imb.br
 ind.br inf.br jor.br lel.br mat.br med.br mil.br mus.br net.br nom.br not.br
 ntr.br odo.br org.br ppg.br pro.br psc.br psi.br qsl.br rec.br slg.br srv.br
 tmp.br trd.br tur.br tv.br vet.br zlg.br com.bs net.bs org.bs ab.ca bc.ca gc.ca
 mb.ca nb.ca nf.ca nl.ca ns.ca nt.ca nu.ca on.ca pe.ca qc.ca sk.ca yk.ca co.ck
 edu.ck gov.ck net.ck org.ck ac.cn ah.cn bj.cn com.cn cq.cn edu.cn gd.cn gov.cn
 gs.cn gx.cn gz.cn hb.cn he.cn hi.cn hk.cn hl.cn hn.cn jl.cn js.cn ln.cn mo.cn
 net.cn nm.cn nx.cn org.cn qh.cn sc.cn sh.cn sn.cn sx.cn tj.cn tw.cn xj.cn xz.cn
 yn.cn zj.cn arts.co com.co edu.co firm.co gov.co info.co int.co mil.co nom.co
 org.co rec.co store.co web.co au.com br.com cn.com de.com eu.com gb.com hu.com
 no.com qc.com ru.com sa.com se.com uk.com us.com uy.com za.com ac.cr co.cr ed.cr
 fi.cr go.cr or.cr sa.cr com.cu net.cu org.cu ac.cy com.cy gov.cy net.cy org.cy
 co.dk art.do com.do edu.do gob.do gov.do mil.do net.do org.do sld.do web.do
 art.dz ***.dz com.dz edu.dz gov.dz net.dz org.dz pol.dz com.ec edu.ec fin.ec
 gov.ec med.ec mil.ec net.ec org.ec com.ee fie.ee med.ee org.ee pri.ee com.eg
 edu.eg eun.eg gov.eg net.eg org.eg sci.eg com.er edu.er gov.er ind.er mil.er
 net.er org.er com.es edu.es gob.es nom.es org.es biz.et com.et edu.et gov.et
 info.et name.et net.et org.et ac.fj com.fj gov.fj id.fj org.fj school.fj ac.fk
 com.fk gov.fk net.fk nom.fk org.fk aeroport.fr assedic.fr asso.fr avocat.fr
 avoues.fr barreau.fr cci.fr chambagri.fr com.fr gouv.fr greta.fr medecin.fr
 nom.fr notaires.fr pharmacien.fr port.fr prd.fr presse.fr tm.fr veterinaire.fr
 com.ge edu.ge gov.ge mil.ge net.ge org.ge pvt.ge ac.gg alderney.gg co.gg gov.gg
 guernsey.gg ind.gg ltd.gg net.gg org.gg sark.gg sch.gg com.gr edu.gr gov.gr
 net.gr org.gr com.gt edu.gt gob.gt ind.gt mil.gt net.gt org.gt com.gu edu.gu
 gov.gu mil.gu net.gu org.gu com.hk edu.hk gov.hk idv.hk net.hk org.hk agrar.hu
 bolt.hu casino.hu city.hu co.hu erotica.hu erotika.hu film.hu forum.hu games.hu
 hotel.hu info.hu ingatlan.hu jogasz.hu konyvelo.hu lakas.hu media.hu news.hu
 org.hu priv.hu reklam.hu sex.hu shop.hu sport.hu suli.hu szex.hu tm.hu tozsde.hu
 utazas.hu video.hu ac.id co.id go.id mil.id net.id or.id ac.il co.il gov.il
 idf.il muni.il net.il org.il ac.im co.im gov.im net.im nic.im org.im ac.in co.in
 ernet.in firm.in gen.in gov.in ind.in mil.in net.in nic.in org.in res.in ac.ir
 co.ir gov.ir id.ir net.ir org.ir sch.ir ac.je co.je gov.je ind.je jersey.je
 ltd.je net.je org.je sch.je com.jo edu.jo gov.jo mil.jo net.jo org.jo ac.jp
 ad.jp aichi.jp akita.jp aomori.jp chiba.jp co.jp ed.jp ehime.jp fukui.jp
 fukuoka.jp fukushima.jp gifu.jp go.jp gov.jp gr.jp gunma.jp hiroshima.jp
 hokkaido.jp hyogo.jp ibaraki.jp ishikawa.jp iwate.jp kagawa.jp kagoshima.jp
 kanagawa.jp kanazawa.jp kawasaki.jp kitakyushu.jp kobe.jp kochi.jp kumamoto.jp
 kyoto.jp lg.jp matsuyama.jp mie.jp miyagi.jp miyazaki.jp nagano.jp nagasaki.jp
 nagoya.jp nara.jp ne.jp net.jp niigata.jp oita.jp okayama.jp okinawa.jp or.jp
 org.jp osaka.jp saga.jp saitama.jp sapporo.jp sendai.jp shiga.jp shimane.jp
 shizuoka.jp takamatsu.jp tochigi.jp tokushima.jp tokyo.jp tottori.jp toyama.jp
 utsunomiya.jp wakayama.jp yamagata.jp yamaguchi.jp yamanashi.jp yokohama.jp
 com.kh edu.kh gov.kh mil.kh net.kh org.kh per.kh ac.kr co.kr go.kr kyonggi.kr
 ne.kr or.kr pe.kr re.kr seoul.kr com.kw edu.kw gov.kw net.kw org.kw com.la
 net.la org.la com.lb edu.lb gov.lb mil.lb net.lb org.lb com.lc edu.lc gov.lc
 net.lc org.lc asn.lv com.lv conf.lv edu.lv gov.lv id.lv mil.lv net.lv org.lv
 com.ly net.ly org.ly ac.ma co.ma net.ma org.ma press.ma com.mk com.mm edu.mm
 gov.mm net.mm org.mm com.mn edu.mn gov.mn museum.mn org.mn com.mo edu.mo gov.mo
 net.mo org.mo com.mt edu.mt net.mt org.mt tm.mt uu.mt com.mx edu.mx gob.mx
 net.mx org.mx com.my edu.my gov.my net.my org.my alt.na com.na cul.na edu.na
 net.na org.na telecom.na unam.na com.nc net.nc org.nc de.net gb.net uk.net ac.ng
 com.ng edu.ng gov.ng net.ng org.ng sch.ng com.ni edu.ni gob.ni net.ni nom.ni
 org.ni tel.no com.np edu.np gov.np net.np org.np fax.nr mob.nr mobil.nr
 mobile.nr tel.nr tlf.nr ac.nz co.nz cri.nz geek.nz gen.nz govt.nz iwi.nz
 maori.nz mil.nz net.nz org.nz parliament.nz school.nz ac.om biz.om co.om com.om
 edu.om gov.om med.om mod.om museum.om net.om org.om pro.om dk.org eu.org ac.pa
 com.pa edu.pa gob.pa net.pa org.pa sld.pa com.pe edu.pe gob.pe mil.pe net.pe
 nom.pe org.pe ac.pg com.pg net.pg com.ph mil.ph net.ph ngo.ph org.ph biz.pk
 com.pk edu.pk fam.pk gob.pk gok.pk gon.pk gop.pk gos.pk gov.pk net.pk org.pk
 web.pk agro.pl aid.pl art.pl atm.pl auto.pl bialystok.pl biz.pl com.pl edu.pl
 gda.pl gmina.pl gsm.pl info.pl katowice.pl krakow.pl lodz.pl lublin.pl mail.pl
 media.pl miasta.pl mil.pl net.pl nieruchomosci.pl nom.pl olsztyn.pl org.pl pc.pl
 powiat.pl poznan.pl priv.pl radom.pl realestate.pl rel.pl sex.pl shop.pl
 sklep.pl slupsk.pl sos.pl szczecin.pl szkola.pl targi.pl tm.pl torun.pl
 tourism.pl travel.pl turystyka.pl waw.pl wroc.pl zgora.pl edu.ps gov.ps plo.ps
 sec.ps com.pt edu.pt gov.pt int.pt net.pt nome.pt org.pt publ.pt com.py edu.py
 net.py org.py com.qa edu.qa gov.qa net.qa org.qa asso.re com.re nom.re arts.ro
 com.ro firm.ro info.ro nom.ro nt.ro org.ro rec.ro store.ro tm.ro www.ro com.ru
 gov.ru net.ru org.ru pp.ru com.sa edu.sa gov.sa med.sa net.sa org.sa pub.sa
 sch.sa com.sb edu.sb gov.sb net.sb org.sb com.sd edu.sd gov.sd med.sd net.sd
 org.sd sch.sd bd.se brand.se fh.se fhsk.se fhv.se komforb.se kommunalforbund.se
 komvux.se lanarb.se lanbib.se mil.se naturbruksgymn.se org.se parti.se pp.se
 press.se sshn.se tm.se com.sg edu.sg gov.sg net.sg org.sg per.sg com.sh edu.sh
 gov.sh mil.sh net.sh org.sh co.st com.st consulado.st edu.st embaixada.st gov.st
 mil.st net.st org.st principe.st saotome.st store.st com.sv edu.sv gob.sv org.sv
 red.sv com.sy gov.sy net.sy org.sy ac.th co.th go.th net.th or.th com.tn
 edunet.tn ens.tn fin.tn gov.tn ind.tn info.tn intl.tn nat.tn net.tn org.tn
 rnrt.tn rns.tn rnu.tn tourism.tn bbs.tr com.tr edu.tr gen.tr gov.tr mil.tr
 net.tr org.tr aero.tt at.tt au.tt be.tt biz.tt ca.tt co.tt com.tt coop.tt de.tt
 dk.tt edu.tt es.tt eu.tt fr.tt gov.tt info.tt int.tt it.tt jobs.tt mobi.tt
 museum.tt name.tt net.tt nic.tt org.tt pro.tt se.tt travel.tt uk.tt us.tt co.tv
 com.tw edu.tw gov.tw idv.tw net.tw org.tw com.ua edu.ua gov.ua net.ua org.ua
 ac.ug co.ug go.ug or.ug ac.uk co.uk edu.uk gov.uk ltd.uk me.uk mod.uk net.uk
 nhs.uk nic.uk org.uk plc.uk police.uk sch.uk dni.us fed.us com.uy edu.uy gub.uy
 mil.uy net.uy org.uy arts.ve bib.ve co.ve com.ve edu.ve firm.ve gov.ve info.ve
 int.ve mil.ve net.ve nom.ve org.ve rec.ve store.ve tec.ve web.ve co.vi net.vi
 org.vi ac.vn biz.vn com.vn edu.vn gov.vn health.vn info.vn int.vn name.vn net.vn
 org.vn pro.vn ch.vu com.vu de.vu edu.vu fr.vu net.vu org.vu com.ws edu.ws gov.ws
 net.ws org.ws com.ye edu.ye gov.ye mil.ye net.ye org.ye ac.yu co.yu edu.yu
 org.yu ac.za agric.za alt.za bourse.za city.za co.za edu.za gov.za law.za mil.za
 net.za ngo.za nis.za nom.za org.za school.za tm.za web.za ac.zw co.zw gov.zw
 org.zw"

#start with domain-stripping




if echo $DOMAIN_LIST | grep -w $end > /dev/null; then
    echo $link | cut -d"." -f$thrd,$fst,$scnd
else
    echo $link | cut -d"." -f$fst,$scnd
fi
done < "$filename" 
}
output > out_temp.txt
#uniq out_temp.txt > out_temp.txt

sort -u out_temp.txt >> out.txt

