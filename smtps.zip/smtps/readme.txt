

download and install python2.7.18 for 64bits
 https://www.python.org/downloads/release/python-2718/

open dos prompt ( cmd ) via run 
copy and paste respectively wherey python2 is install in C:\Python27 directory

cd C:\Python27

python -m pip install --upgrade pip
pip install colorama
pip install socks 
pip install requests 
pip install modules
pip install bs4
pip install tldextract
pip install datetime



command to start

open command prompt 

cd C:\the directory where the crack file is  ( i normally put mine in the C:\OX2SMTP )

1. cd C:\OX2SMTP       enter

2. python crack.py emails.txt 666 0

where 
emails.txt is the notepad with sorted leads to crack on each line
666 is the thread ( it can be any number depending on your ram )
0 is the crack option for smtp
