while IFS='' read -r line || [[ -n "$line" ]]; do
    ./full.sh $line
done < "$1"
